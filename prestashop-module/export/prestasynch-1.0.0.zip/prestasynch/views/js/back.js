/**
 * JavaScript pour la page d'administration du module PrestaSynch
 */

$(document).ready(function() {
  /**
   * Gestion de la synchronisation manuelle
   */
  $('#manual-sync-btn').click(function(e) {
    // Afficher l'indicateur de chargement
    var $btn = $(this);
    var originalHtml = $btn.html();
    
    $btn.html('<i class="process-icon-refresh sync-loading"></i> Synchronisation en cours...');
    $btn.prop('disabled', true);
    
    // Après 2 secondes, simuler la fin de la synchronisation (pour la démo)
    // En production, on attendrait la réponse du serveur
    setTimeout(function() {
      $btn.html(originalHtml);
      $btn.prop('disabled', false);
      
      // Afficher un message de succès
      showNotification('success', 'Synchronisation réussie !');
      
      // Mettre à jour la date de dernière synchronisation
      var now = new Date();
      var formattedDate = now.getDate() + '/' + (now.getMonth() + 1) + '/' + now.getFullYear() + ' ' + 
                          now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
      $('#last-sync-date').text(formattedDate);
    }, 2000);
  });
  
  /**
   * Copier la clé API dans le presse-papier
   */
  $('.copy-api-key').click(function(e) {
    e.preventDefault();
    var apiKey = $('#PRESTASYNCH_API_KEY').val();
    
    // Copier dans le presse-papier
    var tempInput = document.createElement('input');
    tempInput.value = apiKey;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
    
    // Afficher un message de confirmation
    showNotification('success', 'Clé API copiée dans le presse-papier');
  });
  
  /**
   * Générer une nouvelle clé API
   */
  $('.generate-api-key').click(function(e) {
    e.preventDefault();
    var apiKey = generateRandomApiKey();
    $('#PRESTASYNCH_API_KEY').val(apiKey);
    
    // Afficher un message de confirmation
    showNotification('warning', 'Nouvelle clé API générée. N\'oubliez pas d\'enregistrer les modifications !');
  });
  
  /**
   * Afficher une notification
   */
  function showNotification(type, message) {
    var $notification = $('<div class="prestasynch-status ' + type + '">' + message + '</div>');
    $('#prestasynch-notifications').html($notification);
    
    // Faire disparaître la notification après 5 secondes
    setTimeout(function() {
      $notification.fadeOut(500, function() {
        $(this).remove();
      });
    }, 5000);
  }
  
  /**
   * Générer une clé API aléatoire
   */
  function generateRandomApiKey() {
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var length = 32;
    var result = '';
    
    for (var i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return result;
  }
  
  /**
   * Confirmation de désinstallation
   */
  $('.uninstall-module').click(function(e) {
    if (!confirm('Êtes-vous sûr de vouloir désinstaller ce module ? Toutes les données de synchronisation seront perdues.')) {
      e.preventDefault();
    }
  });
});
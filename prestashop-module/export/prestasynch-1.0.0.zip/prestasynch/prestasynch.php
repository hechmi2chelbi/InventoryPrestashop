<?php
/**
 * Module PrestaShop pour la synchronisation avec PrestaSynch
 *
 * @author    PrestaSynch Team
 * @copyright 2024 PrestaSynch
 * @license   https://www.gnu.org/licenses/gpl-3.0.html GPL-3.0
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class PrestaSynch extends Module
{
    /**
     * Configuration du module
     */
    public function __construct()
    {
        $this->name = 'prestasynch';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'PrestaSynch Team';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('PrestaSynch - Synchronisation de produits');
        $this->description = $this->l('Synchronisez les produits, les prix et le stock de votre boutique avec PrestaSynch pour suivre les changements de prix et les alertes de stock.');
        $this->confirmUninstall = $this->l('Êtes-vous sûr de vouloir désinstaller ce module? Toutes les données de synchronisation seront perdues.');
    }

    /**
     * Installation du module
     *
     * @return bool
     */
    public function install()
    {
        // Configuration de base
        Configuration::updateValue('PRESTASYNCH_API_KEY', '');
        Configuration::updateValue('PRESTASYNCH_SYNC_FREQUENCY', 'realtime');
        Configuration::updateValue('PRESTASYNCH_LAST_SYNC', '');
        
        // Installer les tables de base de données
        include(dirname(__FILE__).'/sql/install.php');
        if (isset($sql) && is_array($sql)) {
            foreach ($sql as $query) {
                if (!Db::getInstance()->execute($query)) {
                    return false;
                }
            }
        }
        
        // Installer la table de logs
        $logs_sql_file = dirname(__FILE__).'/sql/install_logs.php';
        if (file_exists($logs_sql_file)) {
            $logs_sql = include($logs_sql_file);
            if (is_array($logs_sql)) {
                foreach ($logs_sql as $query) {
                    if (!Db::getInstance()->execute($query)) {
                        return false;
                    }
                }
            }
        }
        
        $success = parent::install() &&
            $this->registerHook('actionProductUpdate') &&
            $this->registerHook('actionProductAdd') &&
            $this->registerHook('actionUpdateQuantity') &&
            $this->registerHook('actionProductDelete') &&
            $this->registerHook('displayBackOfficeHeader');
            
        // Enregistrer un log d'installation seulement si l'installation a réussi
        if ($success) {
            $this->logActivity('installation', 'success', 'Module PrestaSynch installé avec succès.');
        }
        
        return $success;
    }

    /**
     * Désinstallation du module
     *
     * @return bool
     */
    public function uninstall()
    {
        Configuration::deleteByName('PRESTASYNCH_API_KEY');
        Configuration::deleteByName('PRESTASYNCH_SYNC_FREQUENCY');
        Configuration::deleteByName('PRESTASYNCH_LAST_SYNC');
        
        return parent::uninstall();
    }

    /**
     * Page de configuration du module
     *
     * @return string
     */
    public function getContent()
    {
        $output = '';
        
        // Traitement du formulaire
        if (Tools::isSubmit('submit' . $this->name)) {
            $apiKey = Tools::getValue('PRESTASYNCH_API_KEY');
            $syncFrequency = Tools::getValue('PRESTASYNCH_SYNC_FREQUENCY');
            
            // Validation et enregistrement
            Configuration::updateValue('PRESTASYNCH_API_KEY', $apiKey);
            Configuration::updateValue('PRESTASYNCH_SYNC_FREQUENCY', $syncFrequency);
            
            $output .= $this->displayConfirmation($this->l('Paramètres mis à jour avec succès'));
        }
        
        // Action de synchronisation manuelle
        if (Tools::isSubmit('manual_sync')) {
            $result = $this->syncAllProducts();
            if ($result) {
                $output .= $this->displayConfirmation($this->l('Synchronisation manuelle réussie'));
            } else {
                $output .= $this->displayError($this->l('Erreur lors de la synchronisation manuelle'));
            }
        }
        
        // Affichage du formulaire
        return $output . $this->renderForm();
    }

    /**
     * Génération du formulaire de configuration
     *
     * @return string
     */
    protected function renderForm()
    {
        $helper = new HelperForm();
        
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);
        
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submit' . $this->name;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );
        
        // Construction du formulaire
        $form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Paramètres'),
                    'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Clé API PrestaSynch'),
                        'name' => 'PRESTASYNCH_API_KEY',
                        'desc' => $this->l('Entrez la clé API fournie sur votre compte PrestaSynch'),
                        'required' => true,
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Fréquence de synchronisation'),
                        'name' => 'PRESTASYNCH_SYNC_FREQUENCY',
                        'desc' => $this->l('Choisissez la fréquence à laquelle les données seront synchronisées'),
                        'options' => array(
                            'query' => array(
                                array(
                                    'id' => 'realtime',
                                    'name' => $this->l('Temps réel (à chaque modification)'),
                                ),
                                array(
                                    'id' => 'daily',
                                    'name' => $this->l('Quotidien (une fois par jour)'),
                                ),
                                array(
                                    'id' => 'weekly',
                                    'name' => $this->l('Hebdomadaire (une fois par semaine)'),
                                ),
                            ),
                            'id' => 'id',
                            'name' => 'name',
                        ),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Enregistrer'),
                ),
                'buttons' => array(
                    array(
                        'type' => 'submit',
                        'title' => $this->l('Synchroniser maintenant'),
                        'icon' => 'process-icon-refresh',
                        'class' => 'btn btn-default pull-right',
                        'name' => 'manual_sync',
                    ),
                ),
            ),
        );
        
        // Information sur la dernière synchronisation
        $lastSync = Configuration::get('PRESTASYNCH_LAST_SYNC');
        if (!empty($lastSync)) {
            $syncInfo = '<div class="panel">
                <div class="panel-heading">
                    <i class="icon-time"></i> ' . $this->l('Information de synchronisation') . '
                </div>
                <div class="form-wrapper">
                    <div class="form-group">
                        <p><strong>' . $this->l('Dernière synchronisation:') . '</strong> ' . $lastSync . '</p>
                    </div>
                </div>
            </div>';
        } else {
            $syncInfo = '<div class="panel">
                <div class="panel-heading">
                    <i class="icon-time"></i> ' . $this->l('Information de synchronisation') . '
                </div>
                <div class="form-wrapper">
                    <div class="form-group">
                        <p>' . $this->l('Aucune synchronisation n\'a encore été effectuée') . '</p>
                    </div>
                </div>
            </div>';
        }
        
        return $helper->generateForm(array($form)) . $syncInfo;
    }

    /**
     * Récupération des valeurs de configuration
     *
     * @return array
     */
    protected function getConfigFormValues()
    {
        return array(
            'PRESTASYNCH_API_KEY' => Configuration::get('PRESTASYNCH_API_KEY'),
            'PRESTASYNCH_SYNC_FREQUENCY' => Configuration::get('PRESTASYNCH_SYNC_FREQUENCY'),
        );
    }

    /**
     * Hook pour mettre à jour un produit
     *
     * @param array $params
     */
    public function hookActionProductUpdate($params)
    {
        if (Configuration::get('PRESTASYNCH_SYNC_FREQUENCY') === 'realtime') {
            // Méthode traditionnelle (REST API)
            $this->syncProduct($params['id_product']);
            
            // Ajout de l'approche Webhook
            $this->sendWebhook('product_update', [
                'id' => $params['id_product'],
                'product' => $this->getProductData($params['id_product'])
            ]);
        }
    }

    /**
     * Hook pour ajouter un produit
     *
     * @param array $params
     */
    public function hookActionProductAdd($params)
    {
        if (Configuration::get('PRESTASYNCH_SYNC_FREQUENCY') === 'realtime') {
            // Méthode traditionnelle (REST API)
            $this->syncProduct($params['id_product']);
            
            // Ajout de l'approche Webhook
            $this->sendWebhook('product_add', [
                'id' => $params['id_product'],
                'product' => $this->getProductData($params['id_product'])
            ]);
        }
    }

    /**
     * Hook pour mettre à jour la quantité d'un produit
     *
     * @param array $params
     */
    public function hookActionUpdateQuantity($params)
    {
        if (Configuration::get('PRESTASYNCH_SYNC_FREQUENCY') === 'realtime') {
            // Méthode traditionnelle (REST API)
            $this->syncProduct($params['id_product']);
            
            // Ajout de l'approche Webhook
            $this->sendWebhook('product_quantity_update', [
                'id' => $params['id_product'],
                'product' => $this->getProductData($params['id_product']),
                'quantity' => StockAvailable::getQuantityAvailableByProduct($params['id_product'])
            ]);
        }
    }
    
    /**
     * Récupère les données d'un produit
     * 
     * @param int $idProduct
     * @return array
     */
    private function getProductData($idProduct)
    {
        $product = new Product($idProduct, true, $this->context->language->id);
        
        if (!Validate::isLoadedObject($product)) {
            return [];
        }
        
        return [
            'id' => $product->id,
            'name' => $product->name,
            'reference' => $product->reference,
            'price' => $product->getPrice(),
            'quantity' => StockAvailable::getQuantityAvailableByProduct($product->id)
        ];
    }
    
    /**
     * Envoie un webhook à l'application PrestaSynch
     * 
     * @param string $event Nom de l'événement
     * @param array $data Données associées à l'événement
     * @return bool
     */
    private function sendWebhook($event, $data)
    {
        $apiKey = Configuration::get('PRESTASYNCH_API_KEY');
        if (empty($apiKey)) {
            return false;
        }
        
        $webhookUrl = 'https://prestasynch.com/api/prestashop/webhook';
        
        // Pour faciliter les tests en local ou sur l'environnement Replit
        if (defined('_REPLIT_URL_')) {
            $webhookUrl = rtrim(_REPLIT_URL_, '/') . '/api/prestashop/webhook';
        }
        
        $payload = [
            'event' => $event,
            'timestamp' => time(),
            'shop' => [
                'name' => Configuration::get('PS_SHOP_NAME'),
                'url' => Tools::getShopDomainSsl(true),
                'version' => _PS_VERSION_
            ],
            'data' => $data
        ];
        
        try {
            $ch = curl_init($webhookUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'X-API-Key: ' . $apiKey
            ]);
            
            // L'authentification HTTP Basic a été supprimée pour simplifier l'intégration
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            return $httpCode >= 200 && $httpCode < 300;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Synchronisation d'un produit avec PrestaSynch
     *
     * @param int $idProduct
     * @return bool
     */
    protected function syncProduct($idProduct)
    {
        $apiKey = Configuration::get('PRESTASYNCH_API_KEY');
        if (empty($apiKey)) {
            return false;
        }
        
        // Récupération des informations du produit
        $product = new Product($idProduct, true);
        if (!Validate::isLoadedObject($product)) {
            return false;
        }
        
        $productData = array(
            'id' => $product->id,
            'name' => $product->name[$this->context->language->id],
            'reference' => $product->reference,
            'price' => $product->getPrice(),
            'quantity' => StockAvailable::getQuantityAvailableByProduct($product->id)
        );
        
        // Envoi des données à l'API PrestaSynch
        return $this->sendToApi('products', array('product' => $productData));
    }

    /**
     * Synchronisation de tous les produits
     *
     * @return bool
     */
    protected function syncAllProducts()
    {
        $apiKey = Configuration::get('PRESTASYNCH_API_KEY');
        if (empty($apiKey)) {
            return false;
        }
        
        // Récupération de tous les produits actifs
        $products = Product::getProducts($this->context->language->id, 0, 0, 'id_product', 'ASC', false, true);
        
        if (!$products) {
            return false;
        }
        
        $productsData = array();
        
        foreach ($products as $product) {
            $productObj = new Product($product['id_product'], true);
            $productsData[] = array(
                'id' => $productObj->id,
                'name' => $productObj->name[$this->context->language->id],
                'reference' => $productObj->reference,
                'price' => $productObj->getPrice(),
                'quantity' => StockAvailable::getQuantityAvailableByProduct($productObj->id)
            );
        }
        
        // Envoi des données à l'API PrestaSynch
        $result = $this->sendToApi('sync', array('products' => $productsData));
        
        if ($result) {
            Configuration::updateValue('PRESTASYNCH_LAST_SYNC', date('Y-m-d H:i:s'));
        }
        
        return $result;
    }

    /**
     * Envoi des données à l'API PrestaSynch
     *
     * @param string $endpoint
     * @param array $data
     * @return bool
     */
    protected function sendToApi($endpoint, $data)
    {
        $apiKey = Configuration::get('PRESTASYNCH_API_KEY');
        $apiUrl = 'https://prestasynch.com/api/prestashop/webhook?api_key=' . urlencode($apiKey);
        
        // Pour faciliter les tests en local ou sur l'environnement Replit
        if (defined('_REPLIT_URL_')) {
            $apiUrl = rtrim(_REPLIT_URL_, '/') . '/api/prestashop/webhook?api_key=' . urlencode($apiKey);
        }
        
        try {
            // Préparation de la requête cURL
            $ch = curl_init($apiUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            
            // En-têtes HTTP
            $headers = array(
                'Content-Type: application/json',
                'X-API-Key: ' . $apiKey
            );
            
            // L'authentification HTTP Basic a été supprimée pour simplifier l'intégration
            
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            
            // Exécution de la requête
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            // En cas d'erreur cURL
            if (curl_errno($ch)) {
                $this->logError('cURL Error: ' . curl_error($ch));
                curl_close($ch);
                return false;
            }
            
            curl_close($ch);
            
            // Vérification de la réponse
            if ($httpCode >= 200 && $httpCode < 300) {
                return true;
            } else {
                $this->logError('API Error: HTTP Code ' . $httpCode . ' - ' . $response);
                return false;
            }
        } catch (Exception $e) {
            $this->logError('API Exception: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Journalisation des erreurs
     *
     * @param string $message
     */
    protected function logError($message)
    {
        $this->logActivity('error', 'error', $message);
        PrestaShopLogger::addLog('[PrestaSynch] ' . $message, 3);
    }
    
    /**
     * Journalisation des activités du module
     *
     * @param string $type Type d'activité (api, sync, error, installation, etc.)
     * @param string $status Statut de l'activité (success, error, warning)
     * @param string $message Message décrivant l'activité
     * @param array $details Détails supplémentaires (optionnel)
     * @return bool Succès ou échec de l'enregistrement
     */
    public function logActivity($type, $status, $message, $details = null)
    {
        try {
            // S'assurer que le type et le statut sont des chaînes
            $type = is_string($type) ? $type : 'unknown';
            $status = is_string($status) ? $status : 'unknown';
            $message = is_string($message) ? $message : 'No message';
            
            // Si details est un objet ou un tableau, le convertir en JSON
            if (is_array($details) || is_object($details)) {
                $detailsJson = json_encode($details);
            } else {
                $detailsJson = $details;
            }
            
            $data = [
                'type' => pSQL($type),
                'status' => pSQL($status),
                'message' => pSQL($message),
                'details' => $detailsJson ? pSQL($detailsJson) : null,
                'date_add' => date('Y-m-d H:i:s')
            ];
            
            // Vérifier si la table existe avant d'insérer
            $table_exists = Db::getInstance()->executeS('SHOW TABLES LIKE \''._DB_PREFIX_.'prestasynch_logs\'');
            if (!$table_exists) {
                return false;
            }
            
            $result = Db::getInstance()->insert('prestasynch_logs', $data);
            
            // Envoyer également les logs à l'application PrestaSynch
            $this->sendLogToApi($type, $status, $message, $details);
            
            return $result;
        } catch (Exception $e) {
            if (class_exists('PrestaShopLogger')) {
                PrestaShopLogger::addLog('[PrestaSynch] Erreur lors de l\'enregistrement du log: ' . $e->getMessage(), 4);
            }
            return false;
        }
    }
    
    /**
     * Récupération des logs d'activité
     *
     * @param int $limit Nombre maximum de logs à récupérer
     * @param string $type Type de log à filtrer (optionnel)
     * @param string $status Statut du log à filtrer (optionnel)
     * @return array Liste des logs
     */
    public function getLogs($limit = 100, $type = null, $status = null)
    {
        $sql = new DbQuery();
        $sql->select('*')
            ->from('prestasynch_logs')
            ->orderBy('date_add DESC')
            ->limit((int)$limit);
        
        if ($type) {
            $sql->where('type = "'.pSQL($type).'"');
        }
        
        if ($status) {
            $sql->where('status = "'.pSQL($status).'"');
        }
        
        $result = Db::getInstance()->executeS($sql);
        
        // Convertir les détails JSON en tableau si présent
        if ($result && is_array($result)) {
            foreach ($result as &$log) {
                if (!empty($log['details'])) {
                    $log['details'] = json_decode($log['details'], true);
                }
            }
        }
        
        return $result ?: [];
    }
    
    /**
     * Effacement des logs d'activité
     *
     * @param string $type Type de log à effacer (optionnel)
     * @param string $status Statut du log à effacer (optionnel)
     * @return bool Succès ou échec de l'opération
     */
    public function clearLogs($type = null, $status = null)
    {
        $where = [];
        
        if ($type) {
            $where[] = 'type = "'.pSQL($type).'"';
        }
        
        if ($status) {
            $where[] = 'status = "'.pSQL($status).'"';
        }
        
        $whereClause = !empty($where) ? ' WHERE ' . implode(' AND ', $where) : '';
        
        return Db::getInstance()->execute('DELETE FROM `'._DB_PREFIX_.'prestasynch_logs`'.$whereClause);
    }
    
    /**
     * Envoi des logs à l'API PrestaSynch
     *
     * @param string $type Type d'activité
     * @param string $status Statut de l'activité
     * @param string $message Message décrivant l'activité
     * @param array $details Détails supplémentaires (optionnel)
     * @return bool Succès ou échec de l'envoi
     */
    private function sendLogToApi($type, $status, $message, $details = null)
    {
        $apiKey = Configuration::get('PRESTASYNCH_API_KEY');
        if (empty($apiKey)) {
            return false;
        }
        
        try {
            $webhookUrl = 'https://prestasynch.com/api/prestashop/logs';
            
            // Pour faciliter les tests en local ou sur l'environnement Replit
            if (defined('_REPLIT_URL_')) {
                $webhookUrl = rtrim(_REPLIT_URL_, '/') . '/api/prestashop/logs';
            }
            
            $payload = [
                'log' => [
                    'type' => $type,
                    'status' => $status,
                    'message' => $message,
                    'details' => $details,
                    'timestamp' => time(),
                ],
                'shop' => [
                    'name' => Configuration::get('PS_SHOP_NAME'),
                    'url' => Tools::getShopDomainSsl(true),
                    'version' => _PS_VERSION_
                ]
            ];
            
            $ch = curl_init($webhookUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'X-API-Key: ' . $apiKey
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            return $httpCode >= 200 && $httpCode < 300;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Hook pour ajouter des scripts dans le back-office
     */
    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name) {
            $this->context->controller->addCSS($this->_path . 'views/css/back.css');
            $this->context->controller->addJS($this->_path . 'views/js/back.js');
        }
    }
}
/**
 * Gestion de l'icône PHSy
 */
$(document).ready(function() {
  // Cette fonction pourrait être utilisée pour personnaliser davantage l'affichage de l'icône
  // dans l'interface d'administration de PrestaShop
  $('.module-prestasynch .icon').html('PHSy');
  
  // Ajouter une classe pour la stylisation personnalisée
  $('.module-prestasynch .icon').addClass('phsy-icon');
});
-- Ajouter une colonne attribute_id à la table products
ALTER TABLE products ADD COLUMN attribute_id INTEGER;
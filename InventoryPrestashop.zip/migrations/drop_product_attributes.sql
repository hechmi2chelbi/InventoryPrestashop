-- Migration pour supprimer la table product_attributes
DROP TABLE IF EXISTS product_attributes;